import {
    saveEventTeams,
    saveEventMatches,
    saveEventRankings,
    saveOfflineEvent,
} from "@/lib/db";

export async function downloadEventBundle(
    eventKey: string,
    eventName: string,
    year: number
) {
    const [teamsRes, matchesRes, rankingsRes] = await Promise.all([
        fetch(`/api/tba/teams/${eventKey}`),
        fetch(`/api/tba/matches/${eventKey}`),
        fetch(`/api/tba/rankings/${eventKey}`),
    ]);

    if (!teamsRes.ok || !matchesRes.ok || !rankingsRes.ok) {
        throw new Error("Failed to download event data.");
    }

    const [teams, matches, rankings] = await Promise.all([
        teamsRes.json(),
        matchesRes.json(),
        rankingsRes.json(),
    ]);

    await Promise.all([
        saveEventTeams(eventKey, teams),
        saveEventMatches(eventKey, matches),
        saveEventRankings(eventKey, rankings),
        saveOfflineEvent({
            eventKey,
            eventName,
            year,
            downloadedAt: new Date().toISOString(),
            lastUpdatedAt: new Date().toISOString(),
        }),
    ]);
}
