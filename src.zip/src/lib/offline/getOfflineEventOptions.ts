import { getOfflineEvents, type OfflineEventRecord } from "@/lib/db";

export async function getOfflineEventOptions(year: string) {
    const events = await getOfflineEvents<OfflineEventRecord[]>();

    return events
        .filter((e) => String(e.year) === year)
        .map((e) => ({
            key: e.eventKey,
            name: e.eventName,
        }))
        .sort((a, b) => a.name.localeCompare(b.name));
}
